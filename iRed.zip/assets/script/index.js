const planSelections = document.querySelectorAll('.plan-selection p');
const plans = document.querySelectorAll('.plan');

planSelections.forEach(p => {
    p.addEventListener('click', () => {
        
        plans.forEach(plan => plan.classList.remove('active'));
        planSelections.forEach(p => p.classList.remove('active'));

        // activa el plan y selección que se hizo clic
        p.classList.add('active');
        const planId = p.getAttribute('data-plan');
        document.getElementById(planId).classList.add('active');
    });
});


// carousel

  $(document).ready(function () {
    // 
    $('#testimonialCarousel').carousel();

    // velocidad de desplazamiento del carrusel
    $('#testimonialCarousel').carousel({
      interval: 5000, 
    });

    // 
    $('#testimonialCarousel').carousel({
      pause: 'hover', // pausa el carrusel cuando el mouse está sobre él
    });
  });

  // carousel de la app
  
  
  document.addEventListener('DOMContentLoaded', function () {
    new bootstrap.Carousel(document.querySelector('#carouselExampleIndicators'), {
      interval: 5000, // Cambia el valor a la cantidad de milisegundos que desees
    });
  });





